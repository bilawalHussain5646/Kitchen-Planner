const e='{"redirect": {"enabled": true, "url": "https://lgkitchenplanner.com/sa_en/kitchen-blog/festive-season-kitchen-cleanup-lg-dishwashers.html"}}';export{e as default};
