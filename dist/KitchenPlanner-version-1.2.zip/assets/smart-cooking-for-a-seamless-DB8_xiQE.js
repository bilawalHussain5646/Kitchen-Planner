const e='{"redirect": {"enabled": true, "url": "https://lgkitchenplanner.com/sa_en/kitchen-blog/smart-cooking-for-a-seamless.html"}}';export{e as default};
