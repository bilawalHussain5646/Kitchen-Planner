const e='{"redirect": {"enabled": true, "url": "https://lgkitchenplanner.com/sa_en/kitchen-blog/3-must-try-easy-microwave.html"}}';export{e as default};
