const e='{"redirect": {"enabled": true, "url": "https://lgkitchenplanner.com/sa_en/kitchen-blog/cooking-for-family-gatherings-guide.html"}}';export{e as default};
