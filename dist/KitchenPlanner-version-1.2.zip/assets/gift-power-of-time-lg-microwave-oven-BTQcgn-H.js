const e='{"redirect": {"enabled": true, "url": "https://lgkitchenplanner.com/sa_en/kitchen-blog/gift-power-of-time-lg-microwave-oven.html"}}';export{e as default};
